# HALLOWEEN EVENT ASSETS GUIDE

## 1. Candies (Конфетки)
Give command in 1.21.4:
```mcfunction
/give @p cookie[custom_model_data={floats:[1.0f]}] 64 # Конфетка 1 (желто-красный фантик)
/give @p cookie[custom_model_data={floats:[2.0f]}] 64 # Конфетка 2 (фиолетовый фантик)
/give @p cookie[custom_model_data={floats:[3.0f]}] 64 # Конфетка 3 (леденец-тыква оранжевый)
/give @p cookie[custom_model_data={floats:[4.0f]}] 64 # Конфетка 4 (зелено-желтый фантик)
/give @p cookie[custom_model_data={floats:[5.0f]}] 64 # Конфетка 5 (круглый леденец)
```

## 2. Witch (Ведьма)
- **Model**: `witch_ready.bbmodel` (located in `halloween/witch_ready.bbmodel`)
- **Item parts**: `paper` with CMD `7300000` .. `7300053` (54 bones)
- **Sounds**: `funtime.halloween.witch_1` .. `funtime.halloween.witch_15`
```mcfunction
/playsound funtime.halloween.witch_1 master @p
```

## 3. Negative Spaces (Сдвиги для меню)
| Символ | Unicode | Пиксели | Описание |
|---|---|---|---|
| \\uE2F0 | `\\uE2F0` | -10px | Сдвиг -10px |
| \\uE2F1 | `\\uE2F1` | -12px | Сдвиг -12px |
| \\uE2F2 | `\\uE2F2` | -179px | Сдвиг -179px |
| \\uE2F3 | `\\uE2F3` | -183px | Сдвиг -183px (фон Event) |
| \\uE2F4 | `\\uE2F4` | -186px | Сдвиг -186px |
| \\uE2F5 | `\\uE2F5` | -188px | Сдвиг -188px |
| \\uE2F6 | `\\uE2F6` | -193px | Сдвиг -193px |
| \\uE2F7 | `\\uE2F7` | -214px | Сдвиг -214px |

## 4. GUI Menus (Символы меню в стиле ReallyWorld)
### Событие Хеллоуин (`event`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE300 | `\uE300` | 256 | 46 | `minecraft:items/f8df503a3a0e5868df759a42.png` |
| \uE301 | `\uE301` | 256 | 46 | `minecraft:items/10df21d4a0ed9da1b2d28001.png` |
| \uE302 | `\uE302` | 256 | 48 | `minecraft:items/75c0d778b76564290106a1ad.png` |
| \uE303 | `\uE303` | 256 | 46 | `minecraft:items/2353bb27ac69b45c45c68d24.png` |
| \uE304 | `\uE304` | 256 | 13 | `minecraft:items/a7ce49bd3276f580cd4048d6.png` |
| \uE305 | `\uE305` | 19 | 18 | `minecraft:items/64b85babaa64667b7b9696ed.png` |

### Сборщик душ (`soul_collector`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE310 | `\uE310` | 256 | 13 | `minecraft:items/76bfb0d9481e67330fa00ba1.png` |
| \uE311 | `\uE311` | 256 | 13 | `minecraft:items/3b6330fa20a222be22f24f17.png` |
| \uE312 | `\uE312` | 256 | 13 | `minecraft:items/1ee493b2878bd1e0fe52c5b1.png` |
| \uE313 | `\uE313` | 256 | 13 | `minecraft:items/894e08a0ba3be48cb09e1aa4.png` |
| \uE314 | `\uE314` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### Телепортация (`teleport`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE320 | `\uE320` | 256 | 13 | `minecraft:items/76bfb0d9481e67330fa00ba1.png` |
| \uE321 | `\uE321` | 256 | 13 | `minecraft:items/429c758cd9683feb57a358b7.png` |
| \uE322 | `\uE322` | 256 | 47 | `minecraft:items/3e7f47435444b55e9dcac3d4.png` |
| \uE323 | `\uE323` | 256 | 47 | `minecraft:items/d6a6f04657c0f17fc58949d5.png` |
| \uE324 | `\uE324` | 256 | 47 | `minecraft:items/2fd5f7c17146dbb1adc2b5b8.png` |
| \uE325 | `\uE325` | 256 | 13 | `minecraft:items/ae66e19c0676bab7a401d7b7.png` |
| \uE326 | `\uE326` | 256 | 47 | `minecraft:items/d336aed727f0730d5c0609ed.png` |
| \uE327 | `\uE327` | 256 | 47 | `minecraft:items/bacf620261adc8fb65bffc73.png` |
| \uE328 | `\uE328` | 256 | 47 | `minecraft:items/e55e522f2ebef494b451d210.png` |
| \uE329 | `\uE329` | 256 | 13 | `minecraft:items/894e08a0ba3be48cb09e1aa4.png` |
| \uE32A | `\uE32A` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### Главное меню (`main_menu`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE330 | `\uE330` | 256 | 13 | `minecraft:items/e6c4000782be33e80da18c0c.png` |
| \uE331 | `\uE331` | 256 | 13 | `minecraft:items/0d237c1cbc275211889420f6.png` |
| \uE332 | `\uE332` | 256 | 13 | `minecraft:items/b4e468e9e42d7ed01c644886.png` |
| \uE333 | `\uE333` | 256 | 13 | `minecraft:items/76bfb0d9481e67330fa00ba1.png` |
| \uE334 | `\uE334` | 256 | 13 | `minecraft:items/54815f629564b8c5a18a14e5.png` |
| \uE335 | `\uE335` | 256 | 13 | `minecraft:items/bb98fec7cb88e21e2cdd49ab.png` |
| \uE336 | `\uE336` | 256 | 13 | `minecraft:items/27c9f19c53625ba081eb2283.png` |
| \uE337 | `\uE337` | 256 | 13 | `minecraft:items/894e08a0ba3be48cb09e1aa4.png` |
| \uE338 | `\uE338` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |
| \uE339 | `\uE339` | 256 | 13 | `minecraft:items/8367a67635cf987f116d9861.png` |
| \uE33A | `\uE33A` | 256 | 13 | `minecraft:items/9de7baf637de5d6cfdf6ccf9.png` |
| \uE33B | `\uE33B` | 256 | 13 | `minecraft:items/2c7decaa3c8aed1e850386c0.png` |

### Донат меню (`donmenu`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE340 | `\uE340` | 256 | 13 | `minecraft:items/e6c4000782be33e80da18c0c.png` |
| \uE341 | `\uE341` | 256 | 13 | `minecraft:items/3d9e0ea773552dd9f52a170a.png` |
| \uE342 | `\uE342` | 256 | 13 | `minecraft:items/2dd62d69551cc1bca8f12f87.png` |
| \uE343 | `\uE343` | 256 | 13 | `minecraft:items/838e6ff1f27eeef207f795df.png` |
| \uE344 | `\uE344` | 256 | 13 | `minecraft:items/eb397b0b1a3e6a518ae75ac3.png` |
| \uE345 | `\uE345` | 256 | 13 | `minecraft:items/dde6815df12ab53071bba6ab.png` |
| \uE346 | `\uE346` | 256 | 13 | `minecraft:items/902cc23071595be601f01bda.png` |
| \uE347 | `\uE347` | 256 | 13 | `minecraft:items/b1f7e023d243667f80a18fb3.png` |
| \uE348 | `\uE348` | 256 | 13 | `minecraft:items/eca3601b1293a77359598ad8.png` |
| \uE349 | `\uE349` | 256 | 13 | `minecraft:items/ca5743a7855d444f3d84347a.png` |
| \uE34A | `\uE34A` | 256 | 13 | `minecraft:items/e91a188f9f361dd072cd1750.png` |
| \uE34B | `\uE34B` | 256 | 13 | `minecraft:items/1ad7d4a4d746fc0cee3839fe.png` |
| \uE34C | `\uE34C` | 256 | 13 | `minecraft:items/b4b64e2ca106b37cc6cb4dd4.png` |
| \uE34D | `\uE34D` | 256 | 13 | `minecraft:items/dc235d904bf606be170fcaaa.png` |
| \uE34E | `\uE34E` | 256 | 13 | `minecraft:items/e93fc5f96ad1a2367f22612c.png` |
| \uE34F | `\uE34F` | 256 | 13 | `minecraft:items/47b729c50c37c65da1c4e680.png` |
| \uE350 | `\uE350` | 256 | 13 | `minecraft:items/70e428fcb9b527166bf904f4.png` |
| \uE351 | `\uE351` | 256 | 13 | `minecraft:items/62147c8057de93a679c94a45.png` |
| \uE352 | `\uE352` | 256 | 13 | `minecraft:items/41e798b04a0a85696adbccf0.png` |
| \uE353 | `\uE353` | 256 | 13 | `minecraft:items/022014ab4832cdccfd5024cf.png` |
| \uE354 | `\uE354` | 256 | 13 | `minecraft:items/99b3d9ce4fe96cccc794f4c4.png` |
| \uE355 | `\uE355` | 256 | 13 | `minecraft:items/cec398a274abaf6119ed4463.png` |
| \uE356 | `\uE356` | 256 | 13 | `minecraft:items/5f30f2ac4ca81d1b6bd0470d.png` |
| \uE357 | `\uE357` | 256 | 13 | `minecraft:items/048449b2eea22a9c5d4cb7c4.png` |
| \uE358 | `\uE358` | 256 | 13 | `minecraft:items/df39b359cdaa8d57fe0d33c5.png` |
| \uE359 | `\uE359` | 256 | 13 | `minecraft:items/70e71d756b2f0b6421c18440.png` |
| \uE35A | `\uE35A` | 256 | 13 | `minecraft:items/27c9f19c53625ba081eb2283.png` |
| \uE35B | `\uE35B` | 256 | 13 | `minecraft:items/a7ce49bd3276f580cd4048d6.png` |
| \uE35C | `\uE35C` | 256 | 13 | `minecraft:items/0824359ad542510f21a04e9b.png` |
| \uE35D | `\uE35D` | 256 | 13 | `minecraft:items/9ac2bf18664a46da7487c411.png` |
| \uE35E | `\uE35E` | 256 | 13 | `minecraft:items/645ccbbc6cb3513a03c0af76.png` |
| \uE35F | `\uE35F` | 256 | 13 | `minecraft:items/dd22c83d8f106ec5897d8f4f.png` |
| \uE360 | `\uE360` | 256 | 13 | `minecraft:items/daea2f90609f8d0bba8595fc.png` |
| \uE361 | `\uE361` | 256 | 13 | `minecraft:items/67dca6262790fa7566fe64aa.png` |
| \uE362 | `\uE362` | 256 | 13 | `minecraft:items/7ea496e791a2196c29c3d4d6.png` |
| \uE363 | `\uE363` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### Магазин доната (`donate`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE370 | `\uE370` | 256 | 13 | `minecraft:items/ed98e5641ccd8ea99ea92521.png` |
| \uE371 | `\uE371` | 256 | 13 | `minecraft:items/9913278e53a6b81e4c7b1447.png` |
| \uE372 | `\uE372` | 256 | 13 | `minecraft:items/62d6e0a9b9ef27e44e7d1749.png` |
| \uE373 | `\uE373` | 256 | 13 | `minecraft:items/27c9f19c53625ba081eb2283.png` |
| \uE374 | `\uE374` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### Аукцион (`auction`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE380 | `\uE380` | 256 | 13 | `minecraft:items/6677adf52217a299186078ef.png` |
| \uE381 | `\uE381` | 256 | 13 | `minecraft:items/e6c4000782be33e80da18c0c.png` |
| \uE382 | `\uE382` | 256 | 13 | `minecraft:items/77686f82addee38744ffdfc5.png` |
| \uE383 | `\uE383` | 256 | 13 | `minecraft:items/8995234f6d5eea117a72c2e8.png` |
| \uE384 | `\uE384` | 256 | 13 | `minecraft:items/65370c1ccdee69e6f0160a37.png` |
| \uE385 | `\uE385` | 256 | 13 | `minecraft:items/7a2bba2097bb7e5bb4206be5.png` |
| \uE386 | `\uE386` | 256 | 13 | `minecraft:items/fa6b65d1e19f140fe5123d03.png` |
| \uE387 | `\uE387` | 256 | 13 | `minecraft:items/bd81c42d485c448f8fb4355e.png` |
| \uE388 | `\uE388` | 256 | 13 | `minecraft:items/792f5fdb661ee077879abd3c.png` |
| \uE389 | `\uE389` | 256 | 13 | `minecraft:items/b358b96457dab78dc323339a.png` |
| \uE38A | `\uE38A` | 256 | 13 | `minecraft:items/808da55a7a786a661831d790.png` |
| \uE38B | `\uE38B` | 256 | 13 | `minecraft:items/2e08f7d5642a065c431f07e5.png` |
| \uE38C | `\uE38C` | 256 | 13 | `minecraft:items/66fbfb8e0c06cd1e4402f38d.png` |
| \uE38D | `\uE38D` | 256 | 13 | `minecraft:items/fb465948ddcb63d702a9e8bb.png` |
| \uE38E | `\uE38E` | 256 | 13 | `minecraft:items/558801df83a1393667c32aa8.png` |
| \uE38F | `\uE38F` | 256 | 13 | `minecraft:items/eb0befb0b3b3842fed5c9fb5.png` |
| \uE390 | `\uE390` | 256 | 13 | `minecraft:items/57a6e38f55eb3fd3c1e95f01.png` |
| \uE391 | `\uE391` | 256 | 13 | `minecraft:items/3255c790f6671b93d9012538.png` |
| \uE392 | `\uE392` | 256 | 13 | `minecraft:items/d5da5c6927eefa6eb5cc8322.png` |
| \uE393 | `\uE393` | 256 | 13 | `minecraft:items/497b70c4bd05631e53c5310a.png` |
| \uE394 | `\uE394` | 256 | 13 | `minecraft:items/beab098f8f0923c83888ae2b.png` |
| \uE395 | `\uE395` | 256 | 13 | `minecraft:items/c96539463e80712a3cec3d86.png` |
| \uE396 | `\uE396` | 256 | 13 | `minecraft:items/1e6385dc56a40edbd5f85e3e.png` |
| \uE397 | `\uE397` | 256 | 13 | `minecraft:items/cb1eb142637fd22a9710d14e.png` |
| \uE398 | `\uE398` | 256 | 13 | `minecraft:items/37d0bf2e2499b376b25cef23.png` |
| \uE399 | `\uE399` | 256 | 13 | `minecraft:items/70138829299c7bbecff6b677.png` |
| \uE39A | `\uE39A` | 256 | 13 | `minecraft:items/3a14f8d94384b1329b7b5b57.png` |
| \uE39B | `\uE39B` | 256 | 13 | `minecraft:items/90bc432b4586981a5b0b7935.png` |
| \uE39C | `\uE39C` | 256 | 13 | `minecraft:items/429478ed7a3db052e5aca651.png` |
| \uE39D | `\uE39D` | 256 | 13 | `minecraft:items/6288118e59606791ec11cd29.png` |
| \uE39E | `\uE39E` | 256 | 13 | `minecraft:items/51b94e760d95f5d65d22e1b4.png` |
| \uE39F | `\uE39F` | 256 | 13 | `minecraft:items/74dbd76a4ce2c4aa56dcbfa7.png` |
| \uE3A0 | `\uE3A0` | 256 | 13 | `minecraft:items/2cbdf7beb4bae23d93ca104d.png` |
| \uE3A1 | `\uE3A1` | 256 | 13 | `minecraft:items/c12a287e7bed7466734a66c1.png` |
| \uE3A2 | `\uE3A2` | 256 | 13 | `minecraft:items/80cd831eb49113d3f7f50e10.png` |
| \uE3A3 | `\uE3A3` | 256 | 13 | `minecraft:items/58394a3f47f359227d7254ed.png` |
| \uE3A4 | `\uE3A4` | 256 | 13 | `minecraft:items/5498cb038085e4ad28ae7666.png` |
| \uE3A5 | `\uE3A5` | 256 | 13 | `minecraft:items/c7aa643818d7e48f8721859b.png` |
| \uE3A6 | `\uE3A6` | 256 | 13 | `minecraft:items/d036977cc1754601d4585292.png` |
| \uE3A7 | `\uE3A7` | 256 | 13 | `minecraft:items/94f62e685b66370f76470d63.png` |
| \uE3A8 | `\uE3A8` | 256 | 13 | `minecraft:items/71ce1af8226fc457676d225f.png` |
| \uE3A9 | `\uE3A9` | 256 | 13 | `minecraft:items/42a8cb16729236191657773a.png` |
| \uE3AA | `\uE3AA` | 256 | 13 | `minecraft:items/91ff1fee5f0b6f9b045f1670.png` |
| \uE3AB | `\uE3AB` | 256 | 13 | `minecraft:items/8446d5c55322a671febe1f28.png` |
| \uE3AC | `\uE3AC` | 256 | 13 | `minecraft:items/7a4acbdd5b1a07a2abaf7c72.png` |
| \uE3AD | `\uE3AD` | 256 | 13 | `minecraft:items/27c9f19c53625ba081eb2283.png` |
| \uE3AE | `\uE3AE` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |
| \uE3AF | `\uE3AF` | 256 | 13 | `minecraft:items/45f1b3d031ffd2b7ae754c43.png` |
| \uE3B0 | `\uE3B0` | 256 | 13 | `minecraft:items/aa06415a9c61a3dbade9ac34.png` |
| \uE3B1 | `\uE3B1` | 256 | 13 | `minecraft:items/76bfb0d9481e67330fa00ba1.png` |
| \uE3B2 | `\uE3B2` | 256 | 13 | `minecraft:items/894e08a0ba3be48cb09e1aa4.png` |
| \uE3B3 | `\uE3B3` | 256 | 13 | `minecraft:items/904610e86921ef1be0a2bca8.png` |
| \uE3B4 | `\uE3B4` | 256 | 13 | `minecraft:items/924268856711ac04e88b2131.png` |

### Кейсы (`case`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE3B0 | `\uE3B0` | 256 | 13 | `minecraft:items/aa06415a9c61a3dbade9ac34.png` |
| \uE3B1 | `\uE3B1` | 256 | 13 | `minecraft:items/3a4428579d9183ae0d4e1e3f.png` |
| \uE3B2 | `\uE3B2` | 256 | 12 | `minecraft:items/d29b586697d701557ef617e7.png` |
| \uE3B3 | `\uE3B3` | 256 | 12 | `minecraft:items/e0b8969bd1faee2c3de1d687.png` |
| \uE3B4 | `\uE3B4` | 256 | 12 | `minecraft:items/0ecf13aa0e2b9eb63a473a35.png` |
| \uE3B5 | `\uE3B5` | 256 | 12 | `minecraft:items/b608cb13a619dc45723aca7c.png` |
| \uE3B6 | `\uE3B6` | 256 | 12 | `minecraft:items/bddac888226fe2f4db969fc7.png` |
| \uE3B7 | `\uE3B7` | 256 | 12 | `minecraft:items/174e3721dc971d6e6a8a8a6a.png` |
| \uE3B8 | `\uE3B8` | 256 | 12 | `minecraft:items/db3ad82ab34b32432485ef20.png` |
| \uE3B9 | `\uE3B9` | 256 | 12 | `minecraft:items/8553d11648c28c5edb2d9c2b.png` |
| \uE3BA | `\uE3BA` | 256 | 12 | `minecraft:items/c88ecae19708599939448509.png` |
| \uE3BB | `\uE3BB` | 256 | 12 | `minecraft:items/29226ab30d1aab7ccfcd0aff.png` |
| \uE3BC | `\uE3BC` | 256 | 13 | `minecraft:items/a51dc1f91532f6a2c70db71e.png` |
| \uE3BD | `\uE3BD` | 256 | 13 | `minecraft:items/539234a17b9054742ad35119.png` |
| \uE3BE | `\uE3BE` | 256 | 13 | `minecraft:items/76bfb0d9481e67330fa00ba1.png` |
| \uE3BF | `\uE3BF` | 256 | 13 | `minecraft:items/9b306885849c056ec15b4f6f.png` |
| \uE3C0 | `\uE3C0` | 256 | 13 | `minecraft:items/632ac0ebf04cd0f60c5c0723.png` |
| \uE3C1 | `\uE3C1` | 256 | 13 | `minecraft:items/becd4bc91ad94ef0c5eae2c8.png` |
| \uE3C2 | `\uE3C2` | 256 | 13 | `minecraft:items/3d9e0ea773552dd9f52a170a.png` |
| \uE3C3 | `\uE3C3` | 256 | 12 | `minecraft:items/b75da7b4dfd4f7ae2adf0fd5.png` |
| \uE3C4 | `\uE3C4` | 256 | 12 | `minecraft:items/9d832dab7789fcf5a187d5ab.png` |
| \uE3C5 | `\uE3C5` | 256 | 13 | `minecraft:items/76bfb0d9481e67330fa00ba1.png` |
| \uE3C6 | `\uE3C6` | 256 | 12 | `minecraft:items/c6b41853b1db814c5e17c67b.png` |
| \uE3C7 | `\uE3C7` | 256 | 12 | `minecraft:items/d135e5bfd1dfd938f612aadb.png` |
| \uE3C8 | `\uE3C8` | 256 | 13 | `minecraft:items/9d384733b89329b0023e686a.png` |
| \uE3C9 | `\uE3C9` | 256 | 13 | `minecraft:items/894e08a0ba3be48cb09e1aa4.png` |
| \uE3CA | `\uE3CA` | 256 | 13 | `minecraft:items/a7ce49bd3276f580cd4048d6.png` |
| \uE3CB | `\uE3CB` | 256 | 13 | `minecraft:items/34b5e7686b77c56c75df5076.png` |
| \uE3CC | `\uE3CC` | 256 | 12 | `minecraft:items/baf8aff13a7d9d99a182ff1d.png` |
| \uE3CD | `\uE3CD` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### Казино (`casino`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE3D0 | `\uE3D0` | 256 | 13 | `minecraft:items/3d9e0ea773552dd9f52a170a.png` |
| \uE3D1 | `\uE3D1` | 256 | 13 | `minecraft:items/2d0d52ae46afd19b9de08262.png` |
| \uE3D2 | `\uE3D2` | 256 | 13 | `minecraft:items/8ef28aafdbac7cb67927ced3.png` |
| \uE3D3 | `\uE3D3` | 256 | 13 | `minecraft:items/d7e1b5553c9ea5b0942589cb.png` |
| \uE3D4 | `\uE3D4` | 256 | 13 | `minecraft:items/8e5db7c54c8ce51c984c6eaa.png` |
| \uE3D5 | `\uE3D5` | 256 | 13 | `minecraft:items/875e55af12d7719c187b3d66.png` |
| \uE3D6 | `\uE3D6` | 256 | 13 | `minecraft:items/994854eaf92e4771896893b1.png` |
| \uE3D7 | `\uE3D7` | 256 | 13 | `minecraft:items/0eda8256a6b026587fc4b5f9.png` |
| \uE3D8 | `\uE3D8` | 256 | 13 | `minecraft:items/4be9f62cca78edf74cc91a0a.png` |
| \uE3D9 | `\uE3D9` | 256 | 13 | `minecraft:items/45fdf93916a8e880a153a826.png` |
| \uE3DA | `\uE3DA` | 256 | 13 | `minecraft:items/67ee6eb201422adc5d11bbcc.png` |
| \uE3DB | `\uE3DB` | 256 | 13 | `minecraft:items/25e8dd28fe464cb742e57ec5.png` |
| \uE3DC | `\uE3DC` | 256 | 13 | `minecraft:items/7fc5fde45a44101809e4bbda.png` |
| \uE3DD | `\uE3DD` | 256 | 13 | `minecraft:items/a7ce49bd3276f580cd4048d6.png` |
| \uE3DE | `\uE3DE` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### Кланы (`clan`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE3E0 | `\uE3E0` | 256 | 13 | `minecraft:items/e6c4000782be33e80da18c0c.png` |
| \uE3E1 | `\uE3E1` | 256 | 13 | `minecraft:items/ab5dcb9255094428b7077127.png` |
| \uE3E2 | `\uE3E2` | 256 | 13 | `minecraft:items/1cdfddc1843daedeb0a02e43.png` |
| \uE3E3 | `\uE3E3` | 256 | 13 | `minecraft:items/cb23c292a754f1f970ece9e3.png` |
| \uE3E4 | `\uE3E4` | 256 | 13 | `minecraft:items/629ffa28a4285d5866075fc9.png` |
| \uE3E5 | `\uE3E5` | 256 | 13 | `minecraft:items/2c84b90753ddde488bcb62cd.png` |
| \uE3E6 | `\uE3E6` | 256 | 13 | `minecraft:items/206ad55b6aec014fbf0e7b69.png` |
| \uE3E7 | `\uE3E7` | 256 | 13 | `minecraft:items/7f2d81c40107a2b4fa244acf.png` |
| \uE3E8 | `\uE3E8` | 256 | 13 | `minecraft:items/3a5540172b5ec4d17ee2779c.png` |
| \uE3E9 | `\uE3E9` | 256 | 13 | `minecraft:items/95bf11c8f19748dca1c01eb1.png` |
| \uE3EA | `\uE3EA` | 256 | 13 | `minecraft:items/725d20208c211eb976906244.png` |
| \uE3EB | `\uE3EB` | 256 | 13 | `minecraft:items/7532d75549cb9a749de32eba.png` |
| \uE3EC | `\uE3EC` | 256 | 13 | `minecraft:items/6b735f86dcf3a7d2029860b7.png` |
| \uE3ED | `\uE3ED` | 256 | 13 | `minecraft:items/9385196d66a59470c16d2bb7.png` |
| \uE3EE | `\uE3EE` | 256 | 13 | `minecraft:items/911cac98611d648d9a84608e.png` |
| \uE3EF | `\uE3EF` | 256 | 13 | `minecraft:items/27c9f19c53625ba081eb2283.png` |
| \uE3F0 | `\uE3F0` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |
| \uE3F1 | `\uE3F1` | 256 | 13 | `minecraft:items/d6e6b21c6508e4959ab59c23.png` |
| \uE3F2 | `\uE3F2` | 256 | 13 | `minecraft:items/e20d042056688454cc796573.png` |
| \uE3F3 | `\uE3F3` | 256 | 13 | `minecraft:items/45a8774d377cbf7bcfb39a79.png` |
| \uE3F4 | `\uE3F4` | 256 | 13 | `minecraft:items/1a5c53f1fe32afb05f6cd351.png` |
| \uE3F5 | `\uE3F5` | 256 | 13 | `minecraft:items/62d1344a630a6e6f97059294.png` |
| \uE3F6 | `\uE3F6` | 256 | 13 | `minecraft:items/55a58fd3bfbee1b1b41351ba.png` |
| \uE3F7 | `\uE3F7` | 256 | 13 | `minecraft:items/9e2ed4f9b5e7e999146c826e.png` |
| \uE3F8 | `\uE3F8` | 256 | 13 | `minecraft:items/5438333bdb07d7fd9113e030.png` |
| \uE3F9 | `\uE3F9` | 256 | 13 | `minecraft:items/be07836f161ad7bb0a4a83b1.png` |
| \uE3FA | `\uE3FA` | 256 | 13 | `minecraft:items/5d13b33b685055bb521270aa.png` |

### Крафты (`craft`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE400 | `\uE400` | 256 | 13 | `minecraft:items/3d9e0ea773552dd9f52a170a.png` |
| \uE401 | `\uE401` | 256 | 13 | `minecraft:items/0727b05fcadbf99727744d6c.png` |
| \uE402 | `\uE402` | 256 | 13 | `minecraft:items/4465cae73d2f34c354a00b80.png` |
| \uE403 | `\uE403` | 256 | 13 | `minecraft:items/838e056580a1046ae481e5bb.png` |
| \uE404 | `\uE404` | 256 | 13 | `minecraft:items/02c004e083bf6b184e490256.png` |
| \uE405 | `\uE405` | 256 | 13 | `minecraft:items/894e08a0ba3be48cb09e1aa4.png` |
| \uE406 | `\uE406` | 256 | 13 | `minecraft:items/a7ce49bd3276f580cd4048d6.png` |
| \uE407 | `\uE407` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### Кастомизация (`customisation`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE410 | `\uE410` | 256 | 13 | `minecraft:items/e6c4000782be33e80da18c0c.png` |
| \uE411 | `\uE411` | 256 | 13 | `minecraft:items/739a15b0d254d95ae2dcae60.png` |
| \uE412 | `\uE412` | 256 | 13 | `minecraft:items/dd9eb0cb88e77ad54413628e.png` |
| \uE413 | `\uE413` | 256 | 13 | `minecraft:items/8b7ad620f2f48372d22100ca.png` |
| \uE414 | `\uE414` | 256 | 13 | `minecraft:items/0dc2635f63d247455af8a566.png` |
| \uE415 | `\uE415` | 256 | 13 | `minecraft:items/901d1374dea557573c32606a.png` |
| \uE416 | `\uE416` | 256 | 13 | `minecraft:items/b420f71134eb07424886f73b.png` |
| \uE417 | `\uE417` | 256 | 13 | `minecraft:items/27c9f19c53625ba081eb2283.png` |
| \uE418 | `\uE418` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### Дамагер (`damager`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE420 | `\uE420` | 256 | 13 | `minecraft:items/5bbcc7f34fb2f88032d2b8ba.png` |
| \uE421 | `\uE421` | 256 | 13 | `minecraft:items/167f7d412177268da6ba31a4.png` |
| \uE422 | `\uE422` | 256 | 13 | `minecraft:items/13b620d3924bbf227c48f861.png` |
| \uE423 | `\uE423` | 256 | 13 | `minecraft:items/9d384733b89329b0023e686a.png` |
| \uE424 | `\uE424` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### Дизайн (`design`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE430 | `\uE430` | 256 | 13 | `minecraft:items/e6c4000782be33e80da18c0c.png` |
| \uE431 | `\uE431` | 256 | 13 | `minecraft:items/a1da00c88e7e991a801d569c.png` |
| \uE432 | `\uE432` | 256 | 13 | `minecraft:items/9f661fb474cde21613d10874.png` |
| \uE433 | `\uE433` | 256 | 13 | `minecraft:items/11c487bc2e9158b9988d6bd3.png` |
| \uE434 | `\uE434` | 256 | 13 | `minecraft:items/8db2cf1f02c749e0d1ef45b3.png` |
| \uE435 | `\uE435` | 256 | 13 | `minecraft:items/d0487860e6ef2a83e8adf8db.png` |
| \uE436 | `\uE436` | 256 | 13 | `minecraft:items/ef776577a4197ae1a2824fd5.png` |
| \uE437 | `\uE437` | 256 | 13 | `minecraft:items/d8d2c9674162fd8d7ebefb35.png` |
| \uE438 | `\uE438` | 256 | 13 | `minecraft:items/bf18452f353cb17725fbb5db.png` |
| \uE439 | `\uE439` | 256 | 13 | `minecraft:items/a789d6d4a43d202ad808a6cf.png` |
| \uE43A | `\uE43A` | 256 | 13 | `minecraft:items/a8e809cafd9ee206da1e10a3.png` |
| \uE43B | `\uE43B` | 256 | 13 | `minecraft:items/96b956ae02f8b60e7f8454c6.png` |
| \uE43C | `\uE43C` | 256 | 13 | `minecraft:items/c1daf0d4615e83d03e2f86bb.png` |
| \uE43D | `\uE43D` | 256 | 13 | `minecraft:items/2a135cb2d4facea4922f0609.png` |
| \uE43E | `\uE43E` | 256 | 13 | `minecraft:items/87dc930d52726303fe9752be.png` |
| \uE43F | `\uE43F` | 256 | 13 | `minecraft:items/da4300826bd683ffb3492205.png` |
| \uE440 | `\uE440` | 256 | 13 | `minecraft:items/76bfb0d9481e67330fa00ba1.png` |
| \uE441 | `\uE441` | 256 | 13 | `minecraft:items/f4e021b302726abdc7187b5b.png` |
| \uE442 | `\uE442` | 256 | 13 | `minecraft:items/35e0d4804f82b21510a9e847.png` |
| \uE443 | `\uE443` | 256 | 13 | `minecraft:items/fb4aa75e074b3039f27e16e6.png` |
| \uE444 | `\uE444` | 256 | 13 | `minecraft:items/00df8512cee53d7204790de2.png` |
| \uE445 | `\uE445` | 256 | 13 | `minecraft:items/bb266486d3ec08b742720eac.png` |
| \uE446 | `\uE446` | 256 | 13 | `minecraft:items/07455ff8ee10f829ed989670.png` |
| \uE447 | `\uE447` | 256 | 13 | `minecraft:items/2e8854aafb2377dfe7cbd90d.png` |
| \uE448 | `\uE448` | 256 | 13 | `minecraft:items/4d29c994a6554b790f042d0b.png` |
| \uE449 | `\uE449` | 256 | 13 | `minecraft:items/6cfa67e1ea0b00cdd575717c.png` |
| \uE44A | `\uE44A` | 256 | 13 | `minecraft:items/27c9f19c53625ba081eb2283.png` |
| \uE44B | `\uE44B` | 256 | 13 | `minecraft:items/894e08a0ba3be48cb09e1aa4.png` |
| \uE44C | `\uE44C` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### Чародейство (`enchant`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE450 | `\uE450` | 256 | 13 | `minecraft:items/3d9e0ea773552dd9f52a170a.png` |
| \uE451 | `\uE451` | 256 | 13 | `minecraft:items/904216b324b4779fd688f13d.png` |
| \uE452 | `\uE452` | 256 | 13 | `minecraft:items/23625ef553dbba6567f1f718.png` |
| \uE453 | `\uE453` | 256 | 13 | `minecraft:items/a7ce49bd3276f580cd4048d6.png` |
| \uE454 | `\uE454` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### Помощь (`help`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE460 | `\uE460` | 256 | 13 | `minecraft:items/e6c4000782be33e80da18c0c.png` |
| \uE461 | `\uE461` | 256 | 13 | `minecraft:items/d0788ee843603c0702bf695a.png` |
| \uE462 | `\uE462` | 256 | 13 | `minecraft:items/a986d8e88b062722d8f9a384.png` |
| \uE463 | `\uE463` | 256 | 13 | `minecraft:items/2d419dd819fd6892755085e0.png` |
| \uE464 | `\uE464` | 256 | 13 | `minecraft:items/7369b181ff0971e087a03789.png` |
| \uE465 | `\uE465` | 256 | 13 | `minecraft:items/f45d10723e4b6b5891b38d14.png` |
| \uE466 | `\uE466` | 256 | 13 | `minecraft:items/56ecb3918b68826a7bc506da.png` |
| \uE467 | `\uE467` | 256 | 13 | `minecraft:items/8fdf3d828714633ad6d8ec51.png` |
| \uE468 | `\uE468` | 256 | 13 | `minecraft:items/9a0b6ab912ef5b26919d531b.png` |
| \uE469 | `\uE469` | 256 | 13 | `minecraft:items/d270c4627023cb34a2e5ed4d.png` |
| \uE46A | `\uE46A` | 256 | 13 | `minecraft:items/0010a9cc73a5bde50402c185.png` |
| \uE46B | `\uE46B` | 256 | 13 | `minecraft:items/ad2f6189a180c5ebee588b5e.png` |
| \uE46C | `\uE46C` | 256 | 13 | `minecraft:items/dc08a1c7e4f846ca9cb67d6e.png` |
| \uE46D | `\uE46D` | 256 | 13 | `minecraft:items/550e25711f49efed4e021ea9.png` |
| \uE46E | `\uE46E` | 256 | 13 | `minecraft:items/c8bb4a976aae944fdbc23a30.png` |
| \uE46F | `\uE46F` | 256 | 13 | `minecraft:items/cd19d2bc934edcd1e1b78e0d.png` |
| \uE470 | `\uE470` | 256 | 13 | `minecraft:items/b93b08de5987cb6763b593b9.png` |
| \uE471 | `\uE471` | 256 | 13 | `minecraft:items/27c9f19c53625ba081eb2283.png` |
| \uE472 | `\uE472` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### Лотерея (`lottery`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE480 | `\uE480` | 256 | 13 | `minecraft:items/e6c4000782be33e80da18c0c.png` |
| \uE481 | `\uE481` | 256 | 13 | `minecraft:items/3d9e0ea773552dd9f52a170a.png` |
| \uE482 | `\uE482` | 256 | 13 | `minecraft:items/6fea833acd4b6d32616de21b.png` |
| \uE483 | `\uE483` | 256 | 13 | `minecraft:items/4cb4d5426773c829dfb7bd2a.png` |
| \uE484 | `\uE484` | 256 | 20 | `minecraft:items/54b7c9c90157bc810bcff4ed.png` |
| \uE485 | `\uE485` | 256 | 13 | `minecraft:items/d24565efb4d09b2b54cd49e7.png` |
| \uE486 | `\uE486` | 256 | 13 | `minecraft:items/27c9f19c53625ba081eb2283.png` |
| \uE487 | `\uE487` | 256 | 13 | `minecraft:items/a7ce49bd3276f580cd4048d6.png` |
| \uE488 | `\uE488` | 256 | 54 | `minecraft:items/1d403fc91596365df45a9ae9.png` |
| \uE489 | `\uE489` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### NPC (`npc`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE490 | `\uE490` | 256 | 13 | `minecraft:items/cf8bdb2cae6121e5a1757808.png` |
| \uE491 | `\uE491` | 256 | 13 | `minecraft:items/c1f219299a1232ba8619318e.png` |
| \uE492 | `\uE492` | 256 | 13 | `minecraft:items/d0ffc06a791142b2fe81f667.png` |
| \uE493 | `\uE493` | 256 | 13 | `minecraft:items/40e27bde93b86e1eb056324c.png` |
| \uE494 | `\uE494` | 256 | 13 | `minecraft:items/7b243f3e4241af550e8c91c3.png` |
| \uE495 | `\uE495` | 256 | 13 | `minecraft:items/19d637642080e651e8d05868.png` |
| \uE496 | `\uE496` | 256 | 13 | `minecraft:items/b3ea75aa5cf7e8c3038acfef.png` |
| \uE497 | `\uE497` | 256 | 13 | `minecraft:items/f608cc05fd710216e9b36b54.png` |
| \uE498 | `\uE498` | 256 | 13 | `minecraft:items/e5f2603c1b76e75d779a698a.png` |
| \uE499 | `\uE499` | 256 | 13 | `minecraft:items/a5c7e4de7b8601aba2df431c.png` |
| \uE49A | `\uE49A` | 256 | 13 | `minecraft:items/3077e7045301fc3470ccefac.png` |
| \uE49B | `\uE49B` | 256 | 13 | `minecraft:items/f99f730c615a8a97ec95b000.png` |
| \uE49C | `\uE49C` | 256 | 13 | `minecraft:items/76bfb0d9481e67330fa00ba1.png` |
| \uE49D | `\uE49D` | 256 | 13 | `minecraft:items/3d9e0ea773552dd9f52a170a.png` |
| \uE49E | `\uE49E` | 256 | 13 | `minecraft:items/635d933fdd25778afc2e7691.png` |
| \uE49F | `\uE49F` | 256 | 13 | `minecraft:items/99e18d204385700498edc0f4.png` |
| \uE4A0 | `\uE4A0` | 256 | 13 | `minecraft:items/9d384733b89329b0023e686a.png` |
| \uE4A1 | `\uE4A1` | 256 | 13 | `minecraft:items/894e08a0ba3be48cb09e1aa4.png` |
| \uE4A2 | `\uE4A2` | 256 | 13 | `minecraft:items/a7ce49bd3276f580cd4048d6.png` |
| \uE4A3 | `\uE4A3` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### Награды (`prize`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE4B0 | `\uE4B0` | 256 | 13 | `minecraft:items/3d9e0ea773552dd9f52a170a.png` |
| \uE4B1 | `\uE4B1` | 256 | 13 | `minecraft:items/b6d33998b5ebdf945c60cad9.png` |
| \uE4B2 | `\uE4B2` | 256 | 13 | `minecraft:items/ee020499c2dff2ec02569118.png` |
| \uE4B3 | `\uE4B3` | 256 | 13 | `minecraft:items/2297b4a33c372eae181e8213.png` |
| \uE4B4 | `\uE4B4` | 256 | 13 | `minecraft:items/ca8675c7b7e6a86150ffb016.png` |
| \uE4B5 | `\uE4B5` | 256 | 13 | `minecraft:items/2d7d5693424b49d9f1149d37.png` |
| \uE4B6 | `\uE4B6` | 256 | 13 | `minecraft:items/ab9b43c87de33f180aed61e4.png` |
| \uE4B7 | `\uE4B7` | 256 | 13 | `minecraft:items/017d91e44b4a5b848e74c4a9.png` |
| \uE4B8 | `\uE4B8` | 256 | 13 | `minecraft:items/0b1a0ae28ef505010ccbacbb.png` |
| \uE4B9 | `\uE4B9` | 256 | 13 | `minecraft:items/6928f1c43d987fc6eb59ece9.png` |
| \uE4BA | `\uE4BA` | 256 | 13 | `minecraft:items/a7ce49bd3276f580cd4048d6.png` |
| \uE4BB | `\uE4BB` | 256 | 13 | `minecraft:items/9d384733b89329b0023e686a.png` |
| \uE4BC | `\uE4BC` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### PvP меню (`pvp`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE4C0 | `\uE4C0` | 256 | 13 | `minecraft:items/76bfb0d9481e67330fa00ba1.png` |
| \uE4C1 | `\uE4C1` | 256 | 13 | `minecraft:items/3d9e0ea773552dd9f52a170a.png` |
| \uE4C2 | `\uE4C2` | 256 | 13 | `minecraft:items/af0e3a202885968f4dd6c991.png` |
| \uE4C3 | `\uE4C3` | 256 | 13 | `minecraft:items/5d1a61c51af8bc1e6170a2fc.png` |
| \uE4C4 | `\uE4C4` | 256 | 13 | `minecraft:items/1dfb106059d102dedc40bb5e.png` |
| \uE4C5 | `\uE4C5` | 256 | 13 | `minecraft:items/fe5c25ea0497d735bf458e78.png` |
| \uE4C6 | `\uE4C6` | 256 | 13 | `minecraft:items/c353aee9df51ec1ddf04bbf3.png` |
| \uE4C7 | `\uE4C7` | 256 | 13 | `minecraft:items/84a53fb180c118cf9983c5c2.png` |
| \uE4C8 | `\uE4C8` | 256 | 13 | `minecraft:items/88da740829498e6b64326f2c.png` |
| \uE4C9 | `\uE4C9` | 256 | 13 | `minecraft:items/8d6419c6dd81dc27ecb9bb6d.png` |
| \uE4CA | `\uE4CA` | 256 | 13 | `minecraft:items/e6c4000782be33e80da18c0c.png` |
| \uE4CB | `\uE4CB` | 256 | 13 | `minecraft:items/894e08a0ba3be48cb09e1aa4.png` |
| \uE4CC | `\uE4CC` | 256 | 13 | `minecraft:items/a7ce49bd3276f580cd4048d6.png` |
| \uE4CD | `\uE4CD` | 256 | 13 | `minecraft:items/27c9f19c53625ba081eb2283.png` |
| \uE4CE | `\uE4CE` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |
| \uE4CF | `\uE4CF` | 256 | 13 | `minecraft:items/e7e054946ccac3175a5372c9.png` |
| \uE4D0 | `\uE4D0` | 256 | 13 | `minecraft:items/29528f99c8a521c297a44efb.png` |
| \uE4D1 | `\uE4D1` | 256 | 13 | `minecraft:items/b0944be31062607f4221f016.png` |
| \uE4D2 | `\uE4D2` | 256 | 13 | `minecraft:items/feeb86233d20407a6888e73f.png` |
| \uE4D3 | `\uE4D3` | 256 | 13 | `minecraft:items/0ef734094e01064cd7492656.png` |
| \uE4D4 | `\uE4D4` | 256 | 13 | `minecraft:items/0b20635e7ccbe0a88bc81e20.png` |
| \uE4D5 | `\uE4D5` | 256 | 13 | `minecraft:items/9652fec003ba20cabfb256d2.png` |
| \uE4D6 | `\uE4D6` | 256 | 13 | `minecraft:items/2e8e69b02be218f2b3ec2fd2.png` |
| \uE4D7 | `\uE4D7` | 256 | 13 | `minecraft:items/8748f1ef4b57ad871664604b.png` |
| \uE4D8 | `\uE4D8` | 256 | 13 | `minecraft:items/5f6f2a85fa04b85d4c793e82.png` |
| \uE4D9 | `\uE4D9` | 256 | 13 | `minecraft:items/5c541d23f5542621785c7f1b.png` |
| \uE4DA | `\uE4DA` | 256 | 13 | `minecraft:items/46efcbb5fc513d268fb19d6f.png` |

### Починка (`repair`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE4E0 | `\uE4E0` | 256 | 13 | `minecraft:items/dd38c473bc2b39ca69550c5e.png` |
| \uE4E1 | `\uE4E1` | 256 | 13 | `minecraft:items/105a1ef0e192a3744f91af91.png` |
| \uE4E2 | `\uE4E2` | 256 | 13 | `minecraft:items/daa5f38629071cb7afa30e10.png` |
| \uE4E3 | `\uE4E3` | 256 | 13 | `minecraft:items/27c9f19c53625ba081eb2283.png` |
| \uE4E4 | `\uE4E4` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### РТП (`rtp`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE4F0 | `\uE4F0` | 256 | 13 | `minecraft:items/e6c4000782be33e80da18c0c.png` |
| \uE4F1 | `\uE4F1` | 256 | 13 | `minecraft:items/3a47e42ca05aad22465260f2.png` |
| \uE4F2 | `\uE4F2` | 256 | 13 | `minecraft:items/51d4be81ff15bb8607a1728b.png` |
| \uE4F3 | `\uE4F3` | 256 | 13 | `minecraft:items/27c9f19c53625ba081eb2283.png` |
| \uE4F4 | `\uE4F4` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### Настройки (`settings`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE500 | `\uE500` | 256 | 13 | `minecraft:items/e6c4000782be33e80da18c0c.png` |
| \uE501 | `\uE501` | 256 | 13 | `minecraft:items/f3621cd5eabb235f4ee45c81.png` |
| \uE502 | `\uE502` | 256 | 13 | `minecraft:items/cd65145e3c70df5f917d5d12.png` |
| \uE503 | `\uE503` | 256 | 13 | `minecraft:items/f8af74fb84297f28d77aca3d.png` |
| \uE504 | `\uE504` | 256 | 13 | `minecraft:items/c95d73352fcfb5ba2155d05b.png` |
| \uE505 | `\uE505` | 256 | 13 | `minecraft:items/4eadd088d4f2059d017cd27c.png` |
| \uE506 | `\uE506` | 256 | 13 | `minecraft:items/78d9a72cbd473405dcc5199f.png` |
| \uE507 | `\uE507` | 256 | 13 | `minecraft:items/8fc322212206bda1ba2e3ab9.png` |
| \uE508 | `\uE508` | 256 | 13 | `minecraft:items/24d0adecfb790a00f560351f.png` |
| \uE509 | `\uE509` | 256 | 13 | `minecraft:items/616214bfb159dd87e61eaaf2.png` |
| \uE50A | `\uE50A` | 256 | 13 | `minecraft:items/5e028b36a9c9f898bc547531.png` |
| \uE50B | `\uE50B` | 256 | 13 | `minecraft:items/a9df0bafa0839c8a626cba4b.png` |
| \uE50C | `\uE50C` | 256 | 13 | `minecraft:items/957fe317fa4a0c74f3f19f59.png` |
| \uE50D | `\uE50D` | 256 | 13 | `minecraft:items/733d20f51f53f86077c64fe3.png` |
| \uE50E | `\uE50E` | 256 | 13 | `minecraft:items/d51914a31cdb40bea1eff29d.png` |
| \uE50F | `\uE50F` | 256 | 13 | `minecraft:items/3bab6fb72529d8298d1121d1.png` |
| \uE510 | `\uE510` | 256 | 13 | `minecraft:items/adcadc127b57d2e72bc4e30f.png` |
| \uE511 | `\uE511` | 256 | 13 | `minecraft:items/26aced5a02d2568226b1b8d1.png` |
| \uE512 | `\uE512` | 256 | 13 | `minecraft:items/094bd730709017706a9bb6da.png` |
| \uE513 | `\uE513` | 256 | 13 | `minecraft:items/1dc78e0a699ee9d1b8866dc5.png` |
| \uE514 | `\uE514` | 256 | 13 | `minecraft:items/ae98ef22946b59c3c0dda0fb.png` |
| \uE515 | `\uE515` | 256 | 13 | `minecraft:items/fa4034107dbb1d734907ad32.png` |
| \uE516 | `\uE516` | 256 | 13 | `minecraft:items/abbb2e4967f0e39e66d0fb11.png` |
| \uE517 | `\uE517` | 256 | 13 | `minecraft:items/e80d10a8bc0086ef8e54e1fd.png` |
| \uE518 | `\uE518` | 256 | 13 | `minecraft:items/202250cb4c16af9ef65b53ad.png` |
| \uE519 | `\uE519` | 256 | 13 | `minecraft:items/6affec5cabd1e026e6eaabab.png` |
| \uE51A | `\uE51A` | 256 | 13 | `minecraft:items/27c9f19c53625ba081eb2283.png` |
| \uE51B | `\uE51B` | 256 | 13 | `minecraft:items/eaf8622522b5019dd3279275.png` |
| \uE51C | `\uE51C` | 256 | 13 | `minecraft:items/a6d1c3392ed17e8e61be12ce.png` |
| \uE51D | `\uE51D` | 256 | 13 | `minecraft:items/281517f2428b63e8436981e7.png` |
| \uE51E | `\uE51E` | 256 | 13 | `minecraft:items/17c4160c601d8ea8e5e34d8a.png` |
| \uE51F | `\uE51F` | 256 | 13 | `minecraft:items/05469f755237058b96c55d74.png` |
| \uE520 | `\uE520` | 256 | 13 | `minecraft:items/cb8d172e843791ae36d7d4a2.png` |
| \uE521 | `\uE521` | 256 | 13 | `minecraft:items/0ab6bb0bfb7a008ddf7ba864.png` |
| \uE522 | `\uE522` | 256 | 13 | `minecraft:items/0cb95217091da8b587dffc72.png` |
| \uE523 | `\uE523` | 256 | 13 | `minecraft:items/17577370c0ff53f9a12b1c09.png` |
| \uE524 | `\uE524` | 256 | 13 | `minecraft:items/57a285e1b7e79b966bb29abc.png` |
| \uE525 | `\uE525` | 256 | 13 | `minecraft:items/d885ebab97532d83ccc6fcd8.png` |
| \uE526 | `\uE526` | 256 | 13 | `minecraft:items/1377186449fe59d5f26fe967.png` |
| \uE527 | `\uE527` | 256 | 13 | `minecraft:items/22bf245995d2c2ec71fe0a3e.png` |
| \uE528 | `\uE528` | 256 | 13 | `minecraft:items/4d66a8805a3c2423be6ca0ee.png` |
| \uE529 | `\uE529` | 256 | 13 | `minecraft:items/0b5193a4a3704d29e6ae530a.png` |
| \uE52A | `\uE52A` | 256 | 13 | `minecraft:items/161baa1708c127449892ba92.png` |
| \uE52B | `\uE52B` | 256 | 13 | `minecraft:items/e907ea63c9c2762e66df26fe.png` |
| \uE52C | `\uE52C` | 256 | 13 | `minecraft:items/d415c7c41a1ebb1ebfbfdf22.png` |
| \uE52D | `\uE52D` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### Магазин (`shop`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE530 | `\uE530` | 256 | 13 | `minecraft:items/ed98e5641ccd8ea99ea92521.png` |
| \uE531 | `\uE531` | 256 | 13 | `minecraft:items/193bd8aac1e5890619af225a.png` |
| \uE532 | `\uE532` | 256 | 13 | `minecraft:items/aa06415a9c61a3dbade9ac34.png` |
| \uE533 | `\uE533` | 256 | 13 | `minecraft:items/1a0bc9e282cff808c527fcf6.png` |
| \uE534 | `\uE534` | 256 | 13 | `minecraft:items/8f459b1db4eb809c603ee713.png` |
| \uE535 | `\uE535` | 256 | 13 | `minecraft:items/e248f2129fbd7b4e379adcf0.png` |
| \uE536 | `\uE536` | 256 | 13 | `minecraft:items/06c5114026b92664c2a6b4c6.png` |
| \uE537 | `\uE537` | 256 | 13 | `minecraft:items/683a46d6521bd3331c693056.png` |
| \uE538 | `\uE538` | 256 | 13 | `minecraft:items/4198bb2144d6df997e69ae8e.png` |
| \uE539 | `\uE539` | 256 | 13 | `minecraft:items/27c9f19c53625ba081eb2283.png` |
| \uE53A | `\uE53A` | 256 | 13 | `minecraft:items/9d384733b89329b0023e686a.png` |
| \uE53B | `\uE53B` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### Варпы (`warp`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE540 | `\uE540` | 256 | 13 | `minecraft:items/e6c4000782be33e80da18c0c.png` |
| \uE541 | `\uE541` | 256 | 13 | `minecraft:items/bb9a03a8b3f64deae2871a06.png` |
| \uE542 | `\uE542` | 256 | 13 | `minecraft:items/f7a4e64af9b9cfcd1ed8d4ac.png` |
| \uE543 | `\uE543` | 256 | 13 | `minecraft:items/27c9f19c53625ba081eb2283.png` |
| \uE544 | `\uE544` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |

### Боевой пропуск (`battlepass`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE550 | `\uE550` | 256 | 13 | `minecraft:items/e6c4000782be33e80da18c0c.png` |
| \uE551 | `\uE551` | 256 | 13 | `minecraft:items/a4cba3f00aea744706d7ba30.png` |
| \uE552 | `\uE552` | 256 | 13 | `minecraft:items/dcf61f249c82caad7b962ab5.png` |
| \uE553 | `\uE553` | 256 | 13 | `minecraft:items/cc6c47299d01647a885f8d4e.png` |
| \uE554 | `\uE554` | 256 | 13 | `minecraft:items/b28d21cd2689ef71460741f5.png` |
| \uE555 | `\uE555` | 256 | 13 | `minecraft:items/3f3d18910c0cc3feadcb839d.png` |
| \uE556 | `\uE556` | 256 | 13 | `minecraft:items/3a592d6dd68849d24941c232.png` |
| \uE557 | `\uE557` | 256 | 13 | `minecraft:items/ccf6a9664911c2c3b7c1ccad.png` |
| \uE558 | `\uE558` | 256 | 13 | `minecraft:items/5e35911e214972e8157b5e2f.png` |
| \uE559 | `\uE559` | 256 | 13 | `minecraft:items/7306cf2bc098e4a7c96d2bbe.png` |
| \uE55A | `\uE55A` | 256 | 13 | `minecraft:items/3446400eb90f620c2495dac5.png` |
| \uE55B | `\uE55B` | 256 | 13 | `minecraft:items/27c9f19c53625ba081eb2283.png` |
| \uE55C | `\uE55C` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |
| \uE55D | `\uE55D` | 256 | 13 | `minecraft:items/34ff271ad44edc7dc38746d6.png` |
| \uE55E | `\uE55E` | 256 | 13 | `minecraft:items/f025748904f6d9d10e5d21ce.png` |

### Скупщик (`buyer`)
| Символ | Unicode | Height | Ascent | Texture |
|---|---|---|---|---|
| \uE560 | `\uE560` | 256 | 13 | `minecraft:items/e6c4000782be33e80da18c0c.png` |
| \uE561 | `\uE561` | 256 | 13 | `minecraft:items/75c683634ee153329c745004.png` |
| \uE562 | `\uE562` | 256 | 13 | `minecraft:items/c9d9f3344b9b7ada3728cd71.png` |
| \uE563 | `\uE563` | 256 | 13 | `minecraft:items/12853ac42ff3935af950cf92.png` |
| \uE564 | `\uE564` | 256 | 13 | `minecraft:items/12853ac42ff3935af950cf92.png` |
| \uE565 | `\uE565` | 256 | 13 | `minecraft:items/c31b406eef8a4c6e40ed42ef.png` |
| \uE566 | `\uE566` | 256 | 13 | `minecraft:items/12853ac42ff3935af950cf92.png` |
| \uE567 | `\uE567` | 256 | 13 | `minecraft:items/a93194351290d6215db23a0c.png` |
| \uE568 | `\uE568` | 256 | 13 | `minecraft:items/12853ac42ff3935af950cf92.png` |
| \uE569 | `\uE569` | 256 | 13 | `minecraft:items/04239a272af2ed74696dbdf6.png` |
| \uE56A | `\uE56A` | 256 | 13 | `minecraft:items/1eeb2a2119741c4f1b86422c.png` |
| \uE56B | `\uE56B` | 256 | 13 | `minecraft:items/1fc0cf247bc91f190272092c.png` |
| \uE56C | `\uE56C` | 256 | 13 | `minecraft:items/12853ac42ff3935af950cf92.png` |
| \uE56D | `\uE56D` | 256 | 13 | `minecraft:items/03795e3ac35b15b5eb3a7087.png` |
| \uE56E | `\uE56E` | 256 | 13 | `minecraft:items/27c9f19c53625ba081eb2283.png` |
| \uE56F | `\uE56F` | 256 | 13 | `minecraft:items/9d384733b89329b0023e686a.png` |
| \uE570 | `\uE570` | 256 | 47 | `minecraft:items/1d403fc91596365df45a9ae9.png` |
| \uE571 | `\uE571` | 256 | 13 | `minecraft:items/fa49285a62b5e07753894d86.png` |
| \uE572 | `\uE572` | 256 | 13 | `minecraft:items/2afd550c73038fb73f8536ae.png` |



## 5. Event Bossbars (Конфетный сбор — 4 фазы)

| Символ | Unicode | Символ (char) | Фаза | Height | Ascent | Текстура |
|---|---|---|---|---|---|---|
| \uE306 | \uE306 |  | **Набор игроков** (Lobby/Join) | 256 | 17 | minecraft:custom/candies_bossbar_join.png |
| \uE307 | \uE307 |  | **Волна 1** (Леденцовый дождь) | 256 | 17 | minecraft:custom/candies_bossbar_wave1.png |
| \uE308 | \uE308 |  | **Волна 2** (Праздничный ливень) | 256 | 17 | minecraft:custom/candies_bossbar_wave2.png |
| \uE309 | \uE309 |  | **Волна 3** (Конфетный шторм) | 256 | 17 | minecraft:custom/candies_bossbar_wave3.png |

### Описание и особенности:
- **Формат**: 256x256 пикселей, 32-bit ARGB PNG (`height: 256`, `ascent: 17`, полностью идентично структуре `golem_bossbar.png`).
- **Слот для ванильной полосы**: Строки y=19..23 в сегментах полосы (x=45..112 и x=143..210) на 100% прозрачные. Любой цвет ванильного боссбара (жёлтый/оранжевый/фиолетовый/зелёный) отображается внутри рамки.
- **Центральная эмблема**: Хеллоуинская тыква Джек-О'-Лантерн с вырезанными светящимися глазами и улыбкой, из которой выглядывают конфеты (леденец-тыква `Candy 3` и круглый спиральный леденец `Candy 5`), а снизу золотая оправа с янтарным кристаллом.
- **Боковые крылья**: Готическое темно-фиолетовое железо и античное золото с инкрустированными конфетами из РП (`Candy 1` желто-красный фантик слева, `Candy 2` фиолетовый фантик справа), завершающие зажимы с золотыми камнями.

### Примеры использования:
#### Ванильная команда Minecraft 1.21:
```mcfunction
# 1. Создать боссбар:
/bossbar add halloween:candies {"text":"\uE306"}

# 2. Установить цвет и стиль:
/bossbar set halloween:candies color yellow
/bossbar set halloween:candies style progress
/bossbar set halloween:candies max 100
/bossbar set halloween:candies value 75
/bossbar set halloween:candies players @a

# 3. Боссбар с красивым названием события по центру:
/bossbar set halloween:candies name [{"text":"\uE306"},{"text":"\uE2F2"},{"text":"§6§lКОНФЕТНЫЙ СБОР"}]
```

#### В плагинах (TAB, DecentHolograms, BossBar, CMI, MythicMobs):
В строке заголовка боссбара используйте:
`\uE306` или вставьте скопированный символ ``


## 6. Mascot Bossbar (Чёрный Замок для hMascot / Талисман)

| Символ | Unicode | Символ (char) | Назначение | Height | Ascent | Текстура |
|---|---|---|---|---|---|---|
| \uE30A | `\uE30A` | `` | **Талисман / Чёрный Замок** (`hMascot`) | 256 | 17 | `minecraft:custom/mascot_bossbar.png` |

### Описание и особенности:
- **Стиль**: Тёмная готическая крепость / Чёрный Замок (обсидиановые кирпичи, зубчатые стены, дозорные башни по бокам со смотровыми бойницами и цепями).
- **Центр**: Главные крепостные ворота с мистическим светящимся кристаллом Талисмана (неоново-синяя руническая энергия под синий цвет бара `hMascot`).
- **Слот**: Строки y=19..23 в сегментах полосы — 100% прозрачные. Синий ванильный бар (`color: "BLUE"`) ровно светит сквозь прорезь рамки.

### Настройка в `plugins/hMascot/config.yml`:
```yaml
bossbar:
  started:
    color: "BLUE"
    style: "SOLID"
    # Только кастомная рамка Чёрного Замка:
    name: "\uE30A"
    
    # Либо рамка со сдвигом и текстом координат:
    # name: "\uE30A\uE2F2&6Талисман: &f%xCord% %zCord% &8| &6Лидер: &f%leader%"
```


## 7. Плагин «Конфетный Сбор» (RwCandyEvent)

Готовый скомпилированный плагин: `plug/RwCandyEvent-1.0.0.jar` (Java 21 / Paper 1.21).

### Авто-старт по расписанию (МСК):
В `config.yml` настроен блок `schedule`:
```yaml
schedule:
  enabled: true
  timezone: "Europe/Moscow" # Часовой пояс МСК (UTC+3)
  times:
    - "11:00" # Утро
    - "15:00" # Обед
    - "19:00" # Вечер
  days:
    - Monday
    - Tuesday
    - Wednesday
    - Thursday
    - Friday
    - Saturday
    - Sunday
  pre-broadcast:
    enabled: true
    minutes: [5, 1] # Оповещения в чат за 5 мин и 1 мин
```

### Команды плагина:
- `/candies join` — Присоединиться к событию
- `/candies leave` — Покинуть событие
- `/candies next` (или `/candies time`) — Узнать время следующего сбора по МСК и сколько осталось
- `/candies schedule` — Посмотреть всё расписание запусков
- `/candies start [now]` — Запуск ивента админом (`now` — пропуск лобби, сразу Волна 1)
- `/candies wave <1|2|3>` — Включить нужную волну
- `/candies spawn [кол-во]` — Заспавнить конфеты на полу в регионе для проверки
- `/candies region` — Проверить привязку региона WorldGuard
- `/candies edit` — Открыть GUI редактирования наград
- `/candies stop` — Принудительно остановить ивент
- `/candies reload` — Перезагрузить конфиг, расписание и награды
